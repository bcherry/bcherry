// Header File
// Created 3/27/2005; 7:41:50 PM

void textBox(const char*);